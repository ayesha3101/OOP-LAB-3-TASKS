package LAB3TASK3;

public class Student {
    String name;
    int age;
    String gender;
    String[] skills;


    void assignDetails(String name,int age,String gender,String[] skills) {
        this.name=name;
        this.age=age;
        this.gender=gender;
        this.skills=skills;
    }

}