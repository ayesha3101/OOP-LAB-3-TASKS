package LAB3TASK3;

public class Company {
    String companyName;
    String industryType;
    String jobRole;
    String[] requiredSkills;

    void scheduleInterview(Student student){
       boolean doesQualify = false;
       for(String reqSkill : requiredSkills){
           for(String Studentskill : student.skills){
               if(reqSkill.equals(Studentskill)){
                   doesQualify = true;
                   break;
               }
       }
           if(doesQualify){
               break;
           }
       }
       if(doesQualify){
           System.out.println("Meeting scheduled for "+student.name+" at "+companyName);
       }
       else{
           System.out.println("sorry you do not qualify for this position");
       }

    }
    void assignDetailsCompany(String name, String industryType, String jobRole, String[] requiredSkills){
        this.companyName = name;
        this.industryType = industryType;
        this.jobRole = jobRole;
        this.requiredSkills = requiredSkills;


    }

    void displayCompanyDetails(){
        System.out.println("Company Name: " + companyName);
        System.out.println("Industry Type: " + industryType);

    }





}