package LAB3TASK3;

public class Main {
    public static void main(String[] args) {
        Company SystemsLimited = new Company();
        SystemsLimited.assignDetailsCompany("Systems Limited","Tech","Software Engineers",new String[]{"Java","Python","SQL"});
        Company Folio3 = new Company();
        Folio3.assignDetailsCompany("Folio3","Tech","Data Analyst",new String[]{"Machine Learning","Python","Power BI"});
        Student s1 = new Student();
        Student s2 = new Student();
        s1.assignDetails("Ayesha",19,"female",new String[]{"Java","C++","Python"});
        s2.assignDetails("Ahmed",18,"male",new String[]{"HTML","C++","Power BI"});
        SystemsLimited.displayCompanyDetails();
        Folio3.displayCompanyDetails();
        SystemsLimited.scheduleInterview(s1);
        Folio3.scheduleInterview(s2);
        ;
    }
}