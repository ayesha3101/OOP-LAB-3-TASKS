package LAB3TASK1;

public class Main {
    public static void main(String[] args) {
        Stadium s1 =new Stadium();
        s1.name="National Stadium Karachi";
        s1.city="Karachi";
        s1.capacity=1900;
        s1.matchesScheduled=2; //initial value
        Stadium s2 =new Stadium();
        s2.name="Gaddafi Stadium Lahore";
        s2.city="Lahore";
        s2.capacity=900;
        s2.matchesScheduled=1;
        s2.displayDetails();
        System.out.println("details after updating number of matches scheduled through method");
        s2.scheduleMatch(3);
        s2.displayDetails();


    }
}