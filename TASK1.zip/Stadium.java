package LAB3TASK1;

package LAB3TASK1;

public class Stadium {
    String name;
    String city;
    int capacity;
    int matchesScheduled=0;

    void scheduleMatch(int x){
        this.matchesScheduled=this.matchesScheduled+x;
    }
    void displayDetails(){
        System.out.println("Name: "+this.name);
        System.out.println("City: "+this.city);
        System.out.println("Capacity: "+this.capacity);
        System.out.println("MatchesScheduled: "+this.matchesScheduled);
    }


}