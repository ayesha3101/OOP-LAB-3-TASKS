package LAB3TASK5;

import java.util.ArrayList;
import java.util.Scanner;

public class Items {
    public String itemName;
    public String itemID;
    private double itemPrice;
    private int itemStock;
    public static double totalPrice=0;

    public Items(String itemName, String itemID, double itemPrice, int itemStock) {
        this.itemName = itemName;
        this.itemID = itemID;
        this.itemPrice = itemPrice;
        this.itemStock = itemStock;
    }

    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public void setItemStock(int itemStock) {
        this.itemStock = itemStock;
    }
    public double getItemPrice() {
        return itemPrice;
    }
    public int getItemStock() {
        return itemStock;
    }

   public static void displayInventory(ArrayList<Items> item) {
        for (Items item1 : item) {
            System.out.println(item1.itemName +" "+ item1.itemPrice);
        }

   }
   public static void searchItem(ArrayList<Items> item) {
        Scanner sc = new Scanner(System.in);
        int found =0;
       System.out.println("Enter the name of the item");
       String target = sc.nextLine();
       for (Items item1 : item) {
           if (item1.itemName.equals(target)) {
               System.out.println(item1.itemPrice);
               found++;
               break;
           }
       }
       if(found ==0){
           System.out.println("Item not found");
       }
   }

   public static void purchaseItem(ArrayList<Items> item) {
        Scanner sc = new Scanner(System.in);
        int flag =1;
        while (flag!=0){
            displayInventory(item);
            System.out.println("Enter the name of the item");
            String target = sc.nextLine();
            System.out.println("Enter the quantity of items to purchase");
            int quantity = sc.nextInt();
            sc.nextLine();
            for (Items item1 : item) {
                if (item1.itemName.equals(target)) {
                    if (item1.itemStock>=quantity) {
                        item1.itemStock -= quantity;
                        totalPrice += item1.itemPrice * quantity;
                        System.out.println("Item add to basket successfully");
                        break;
                    }
                }
            }
            System.out.println("Do you want to add another item ?(ENTER 1 FOR YES AND 0 FOR NO");
            flag = sc.nextInt();
            sc.nextLine();

        }
       System.out.println("Total price is "+totalPrice);

   }
}
