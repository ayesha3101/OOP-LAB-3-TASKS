package LAB3TASK5;
import java.util.Scanner;
import java.util.ArrayList;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Items> itemsList = new ArrayList<>();
        itemsList.add(new Items("Pizza","3101",300,25));
        itemsList.add(new Items("Milk","3102",290,20));
        itemsList.add(new Items("Pepperoni","3103",310,67));
        itemsList.add(new Items("Cheese","3104",500,70));
        itemsList.add(new Items("honey","3105",800,55));
        itemsList.add(new Items("Cake","3106",1000,12));
        Items.searchItem(itemsList);
        Items.purchaseItem(itemsList);



    }
}