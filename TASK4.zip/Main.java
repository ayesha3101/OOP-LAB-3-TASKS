package LAB3TASK4;

public class Main {
    public static void main(String[] args) {
        Course c1 = new Course();
        c1.SetDetails("Programming fundamentals","CS101",3);
        System.out.println("Details of the course");
        System.out.println("Course name: "+c1.getCourseName());
        System.out.println("Course code: "+c1.getCourseCode());
        System.out.println("Credit hours: "+c1.getCreditHours());

    }
}