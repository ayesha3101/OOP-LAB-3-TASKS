package LAB3TASK4;

public class Course {
    String courseName;
    String courseCode;
    int creditHours;


    public void SetDetails(String courseName, String courseCode, int creditHours) {
      this.courseName = courseName;
      if(courseCode.matches(".*[A-Z].*")){
          if(courseCode.matches(".*\\d.*")){
                this.courseCode = courseCode;
            }
        }
      if(creditHours > 0 && creditHours <= 4){
          this.creditHours = creditHours;
      }
    }

    public String getCourseName() {
        return courseName;
    }
    public String getCourseCode(){
        return courseCode;
    }
    public int getCreditHours() {
        return creditHours;
    }

}

