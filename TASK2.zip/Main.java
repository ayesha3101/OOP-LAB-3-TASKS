package LAB3TASK2;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Session s1 = new Session();
        s1.scheduleSession("AI in modern apps","Ayesha Naveed","E-29",2);
        Session s2 = new Session();
        s2.scheduleSession("Cybersecurity","Elon Musk","E-30",1);
        s1.displaySession();
        s2.displaySession();
    }


}