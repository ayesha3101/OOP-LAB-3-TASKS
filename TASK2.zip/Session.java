package LAB3TASK2;

import javax.swing.*;

public class Session {
    String sessionTitle;
    String speakerName;
    String roomNumber;
    int duration;

    void scheduleSession(String name , String speaker,String room , int dur) {
        this.sessionTitle = name;
        this.speakerName = speaker;
        this.roomNumber = room;
        this.duration = dur;
    }
    void displaySession() {
        System.out.println("Session Title: " + this.sessionTitle);
        System.out.println("Speaker Name: " + this.speakerName);
        System.out.println("Room Number: " + this.roomNumber);
        System.out.println("Duration: " + this.duration);
    }
}