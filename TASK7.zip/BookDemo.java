package LAB3TASK7;

public class BookDemo {
    public static void main(String[] args){
        Book b1 = new Book("Java: a beginners guide","Hebert Schedlt",100.95);
        String details = b1.toString();
        System.out.println(details);
        b1.setPrice(99.99);
        details = b1.toString();
        System.out.println(details);
    }

}