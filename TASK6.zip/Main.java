package LAB3TASK6;

public class Main {
    public static void main(String[] args){
        Student s1 = new Student();
        s1.studentName="Ayesha Naveed";
        s1.age=19;
        s1.courseName="OOP in java";
        System.out.println("My name is "+s1.studentName+". I am "+s1.age+" years old. I am studying "+s1.courseName );
    }

}