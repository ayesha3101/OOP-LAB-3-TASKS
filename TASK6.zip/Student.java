package LAB3TASK6;

public class Student {
    String studentName;
    String courseName;
    int age;

}